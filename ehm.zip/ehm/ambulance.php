<!DOCTYPE html>
<html>
    <head>
       <link rel="stylesheet" type="text/css" href="style.css">
       <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    </head>
    <style  type="text/css">
            #inputbtn:hover{cursor:pointer;}
        .card{
            background: #222527c7;
            border-top-left-radius: 5% 5%;
            border-bottom-left-radius: 5% 5%;
            border-top-right-radius: 5% 5%;
            border-bottom-right-radius: 5% 5%;

            background: rgba(30, 94, 119, 0.21);
            box-shadow: 11px 18px 4px rgba(0, 0, 0, 0.25);
            border-radius: 30px;
        }
        </style>
 <body>
 <body style="background-color: white; background-size: cover;">
        <nav class="navbar navbar-expand-lg navbar-dark " id="mainNav" style="background-color: black;">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="login.php" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;"><h4><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp HEALTHCARE</h4></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>HOME</h6></a>
                        </li>

                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="about.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>ABOUT US</h6></a>
                        </li>

                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="contact.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>CONTACT</h6></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp LOGIN</h6></a>
                        </li>
                        
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="gallery.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp GALLERY</h6></a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid" style="margin-top:40px;margin-bottom:60px;color:#34495E;">
        <div class="row">

        

            <div class="col-md-7" style="padding-left: 160px; ">
                 <div style="-webkit-animation: mover 2s infinite alternate; animation: mover 1s infinite alternate;">
            <img src="giphy (1).webp" alt="" style="width: 50%;padding-left: 50px;margin-top: 160px;margin-bottom:25px">
        </div>
        <div style="color: black;">
            <h1 style="font-family: 'IBM Plex Sans', sans-serif;"> We are available 24*7</h1>
          </div>

         </div>
        <div class="col-md-5" style="margin-top: 2% ; right:10%">  
        <div class="card">
        <center>
                <i class="fa fa-hospital-o fa-3x" aria-hidden="true" style="color:#0062cc"></i>
              <h3 style="margin-top: 3% "> Book Ambulance</h3><br>
              <form class="form-group" method="post" action="">
                <div class="row" style="margin-top: 10%">
                  <div class="col-md-4"><label>Name: </label></div>
                  <div class="col-md-6"><input type="text" name="name" class="form-control" placeholder="enter name" required/></div>
                  <div class="col-md-4" style="margin-top: 8%" ><label>Phone number: </label></div>
                  <div class="col-md-6" style="margin-top: 8%"><input type="tel" id="phonenub"  minlength="10" maxlength="10" class="form-control" name="phonenub" placeholder="enter phone no." required/></div>
                  <div class="col-md-4" style="margin-top: 8%" ><label>Address:</label></div>
                  <div class="col-md-6" style="margin-top: 8%"><textarea id="text" name="address" class="form-control" placeholder="enter Address" required style="height: 100px"></textarea></div>
                </div>
                <div class="row">
                 <div class="col-md-10"  style="padding-left: 160px;margin-top: 10%">
                    <center><input type="submit" id="inputbtn" name="bookab" value="book" class="btn btn-primary"></center></div>           
                 <!--  <div class="col-md-8" style="margin-top: 10%">
                    <a href="index.php" class="btn btn-primary">Back</a></div> -->
                </div>
              </form>
            </div>
    </center>
        </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

 </body>   
 </html>
 <?php
if(isset($_POST['bookab']))
{
$name=$_POST['name'];
$phonenub=$_POST['phonenub']; 
$address=$_POST['address'];

//established connection;
$con=mysqli_connect("localhost","root","","ehms");
 $query="INSERT INTO `ba`(`name`, `phonenub`, `address`) VALUES ('$name',$phonenub,'$address')";

 if(mysqli_query($con,$query))
{
    ?>
    <script>
        alert("Submitted Successfully.");
    </script>
     <?php
}
else
{
    ?>
     <script>
        alert("Not Submitted Successfully.");
    </script>
<?php
}
}
?>