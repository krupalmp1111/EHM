<!DOCTYPE html>
 <?php #include("func.php");?>
<html>
<head>
	<title>User Messages</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
<?php
include("newfunc.php");
if(isset($_POST['mes_search_submit']))
{
	$pid=$_POST['mes_phonenub'];

	$query = "SELECT * FROM `appointment` WHERE `pid`='$pid'";
  $result = mysqli_query($con,$query);
  if(mysqli_num_rows($result)>0)
  {
    echo "<div class='container-fluid' style='margin-top:50px;'>
    <div class='card'>
    <div class='card-body' style='background-color:#342ac1;color:#ffffff;'>
  <table class='table table-hover'>
    <thead>
      <tr>
      <th scope='col'>Appointment ID</th>
      <th scope='col'>Patient ID</th>
      <th scope='col'>First Name</th>
      <th scope='col'>Last Name</th>
      <th scope='col'>Gender</th>
      <th scope='col'>Contact</th>
      <th scope='col'>Doc Name</th>
      <th scope='col'>Disease</th>
      <th scope='col'>Allergy</th>
      <th scope='col'>Report</th>
      </tr>
    </thead>
    <tbody>";
    $query1=mysqli_query($con,'SELECT * FROM `pt` WHERE `pid`='.$pid.'');
    $row1=mysqli_fetch_assoc($query1);

    while($row=mysqli_fetch_array($result))
    {
        
        $ID = $row['ID'];
        $pid = $row['pid'];
        $fname = $row['fname'];
        $lname = $row['lname'];
        $gender = $row['gender'];
        $contact = $row['contact'];
        $doctor = $row['doctor'];
        $disease = $row1['disease'];
        $allergy = $row1['allergy'];
        $reports = $row1['reports'];

        echo "<tr>
        <td>$ID</td> 
        <td>$pid</td> 
        <td>$fname</td> 
        <td>$lname</td> 
        <td>$gender</td> 
        <td>$contact</td> 
        <td>$doctor</td> 
        <td>$disease</td> 
        <td>$allergy</td> 
        <td>$reports</td> 
          
        </tr>";
  


    }
  echo "</tbody></table><center><a href='lab.php' class='btn btn-light'>Back to your Dashboard</a></div></center></div></div></div>";

  }
  else
  {
    echo "<script> alert('No entries found! Please enter valid details'); 
    window.location.href = 'lab.php#list-doc';</script>";
  }
  }
	
?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script> 
</body>
</html>