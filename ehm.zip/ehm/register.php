<!--Login  the database of pt>
<?php
session_start();
$con=mysqli_connect("localhost","root","","ehms");

$email=$_POST['email'];
echo $email;
// if(isset($_POST['patsub']))
// {
// 	$email=$_POST['email'];
// 	$password=$_POST['password2'];
//   echo $email;
// 	// $query="select * from ptreg where email='$email' and password='$password';";
// 	// $result=mysqli_query($con,$query);
// 	// if(mysqli_num_rows($result)==1)
// 	// {
// 		// while($row=mysqli_fetch_array($result)){
//     //   $_SESSION['pid'] = $row['pid'];
//     //   $_SESSION['username'] = $row['fname']." ".$row['lname'];
//     //   $_SESSION['fname'] = $row['fname'];
//     //   $_SESSION['lname'] = $row['lname'];
//     //   $_SESSION['gender'] = $row['gender'];
//     //   $_SESSION['contact'] = $row['contact'];
//     //   $_SESSION['email'] = $row['email'];
//     // }
// 	// 	header("connect.php");
// 	// }
//   // else {
//   //   echo("<script>alert('Invalid Username or Password. Try Again!');

//   //         window.location.href = 'ptlogin.php';</script>");
//     // header("Location:error.php");
//       // }
//   }
// ?>