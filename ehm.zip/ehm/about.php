
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="style2.css">
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    </head>
        <style type="text/css">
            #inputbtn:hover{cursor:pointer;}
        .card{
            background: #222527c7;
            border-top-left-radius: 5% 5%;
            border-bottom-left-radius: 5% 5%;
            border-top-right-radius: 5% 5%;
            border-bottom-right-radius: 5% 5%;

            background: rgba(30, 94, 119, 0.21);
            box-shadow: 11px 18px 4px rgba(0, 0, 0, 0.25);
            border-radius: 25px;
        }
        </style>
    <body style="background-color: white; background-size: cover;">
        <nav class="navbar navbar-expand-lg navbar-dark " id="mainNav" style="background-color: black;">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="login.php" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;"><h4><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp HEALTHCARE</h4></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="home.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>HOME</h6></a>
                        </li>

                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="about.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>ABOUT US</h6></a>
                        </li>

                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="contact.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>CONTACT</h6></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp LOGIN</h6></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="gallery.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp GALLERY</h6></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}
 
.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body>

<div class="about-section">
  <h1>About Us</h1>
  <p>We provide the best services in the healthcare</p>
  <p>Join our community and facilitate our services through our application  </p>
</div>
<div class="col-md-12">
<div class="row">
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>CARDIOLOGY</h2>
        <p class="title">Cardioviscular</p>
        <p>a branch of medicine that deals with disease of the heart.</p>
        <p><button class="button"><a href="contact.php">Contact</button></a></p>
        <img src="7.jfif" alt="Jane" style="width:100%">
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <div class="container">
        <h2>ORTHOPEDIC</h2>
        <p class="title">Speciality</p>
        <p>a medicine dealing with the correction of bones or muscles</p>
        <p><button class="button"><a href="contact.php">Contact</button></a></p>
        <img src="8.jpg" alt="Jane" style="width:100%">
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>OPTHOMOLOGY</h2>
        <p class="title">Visualization</p>
        <p>a subspecialty within medicine that deals eye disorders</p>
        <p><button class="button"><a href="contact.php">Contact</button></a></p>
        <img src="11.jpg" alt="Jane" style="width:100%">
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>GYNCELOGIST</h2>
        <p class="title">Physician</p>
        <p>a physician or surgeon qualified to practise in gynaecology.</p>
        <p><button class="button"><a href="contact.php">Contact</button></a></p>
        <img src="9.jpg" alt="Jane" style="width:100%">
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <div class="container">
        <h2>RADIOLOGIST</h2>
        <p class="title">Scanning</p>
        <p>a person that uses medical imaging to diagnose diseases </p>
        <p><button class="button"><a href="contact.php">Contact</button><a></p>
        <img src="10.jpg" alt="Jane" style="width:100%">
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>HOMOYOPETHAY</h2>
        <p class="title">Alopathy</p>
        <p>a form of medicine in which ailments are treated well </p>
        <p><button class="button"><a href="contact.php">Contact</button><a></p>
        <img src="12.jpg" alt="Jane" style="width:100%">
      </div>
    </div>
  </div>
</div>
</body>
</html>
