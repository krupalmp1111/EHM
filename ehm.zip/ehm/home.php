<!DOCTYPE html>
<html>
    <head>
       <link rel="stylesheet" type="text/css" href="style.css">
       <link rel="stylesheet" type="text/css" href="s.css">
       <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <script src="https://kit.fontawesome.com/a5bda29c88.js" crossorigin="anonymous"></script>
        
    </head>
 <body>
 <nav class="navbar navbar-expand-lg navbar-dark " id="mainNav" style="background-color: black;">
        <div class="container">

<a class="navbar-brand js-scroll-trigger" href="#" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;"><h4><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp HEALTHCARE</h4></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
  <ul class="navbar-nav ml-auto">
    <li class="nav-item" style="margin-right: 40px;">
      <a class="nav-link js-scroll-trigger" href="home.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>HOME</h6></a>
    </li>

    <li class="nav-item" style="margin-right: 40px;">
      <a class="nav-link js-scroll-trigger" href="about.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>ABOUT US</h6></a>
    </li>

    <li class="nav-item">
      <a class="nav-link js-scroll-trigger" href="contact.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>CONTACT</h6></a>
    </li>

    <li class="nav-item">
      <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp LOGIN</h6></a>
    </li>
   
    <li class="nav-item">
      <a class="nav-link js-scroll-trigger" href="gallery.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp GALLERY</h6></a>
    </li>
    <li class="nav-item">
      <a class="nav-link js-scroll-trigger" href="ambulance.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp AMBULANCE</h6></a>
    </li>

  </ul>
</div>
</div>
</nav>
<div class="img">
      </div>
<style>
            *{
                padding: 0;
                margin: 0;
                box-sizing:border-box;
            }
            .img{
                height: 600px;
                width: 100%;
                background-image:url('22.jpg');
                background-image:url('17.jpg');
                background-position: center center;
                background-repeat: repeat;
                background-size: 100% 100%;
                animation-name: myani;
                animation-duration: 6s;
                animation-timing-function: linear;
                animation-iteration-count: infinite;

            }

            @keyframes myani{
                 0% {background-image:url('17.jpg');}
                35%{background-image:url('22.jpg');} 
            } 

            </style> 
            <h1 aligen ="center"> </p>
            <!-- Footer -->
    <footer class="footer">
        <div class="contain1">
            <div class="row">
                <div class="footer-col">

                    <h4>Address</Address></h4>
                    <ul>
                        <li><a style="font-size: 14px;" href="#">Ganpat Vidyanagar Mehsana-Gozaria, Highway, Kherva, Gujarat 384012.</a></li>
                        <li><a style="font-size: 0.8rem;" href="#"><b>Phone:</b> 9874563210</a></li>
                        <li><a style="font-size: 0.8rem;" href="#"><b>Email:</b> ganpatuniversity@gnu.ac.in</a></li>
                        
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>company</h4>
                    <ul>
                        <li><a href="about.php">ABOUT US</a></li>
                        <li><a href="gallery.php">GALLERY</a></li>
                        <li><a href="ambulance.php">AMBULANCE</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>get help</h4>
                    <ul>
                        <li><a href="contact.php">Feedbacks</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <a href="#"><i style="font-size: 30px;" class="fab fa-facebook-f"></i></a>
                        <a href="#"><i style="font-size: 30px;" class="fab fa-twitter"></i></a>
                        <a href="#"><i style="font-size: 35px;" class="fab fa-instagram"></i></a>
                        <a href="#"><i style="font-size: 30px;" class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>