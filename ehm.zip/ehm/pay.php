<?php
$con=mysqli_connect('localhost','root','','ehms');
if (isset($_POST['payment']) && $_POST['amt'] >=99) {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $amount=$_POST['amt'];
    $pay_to='Hospital Bill';
    include 'instamojo\Instamojo.php';
    $api = new Instamojo\Instamojo('test_33a90cfa8c10535ab7cc770d193', 'test_174c7921579f033b2b314ae201c', 'https://test.instamojo.com/api/1.1/');
    try {
        $response = $api->paymentRequestCreate(array(
            "purpose" => $pay_to,
            "user_name" => $name,
            "email" => $email,
            "phone" => $phone,
            "amount" => $amount,
            "send_email" => true,
            "redirect_url" => "http://localhost/Payment/thankyou.php"
            ));
       // print_r($response);
        $url=$response['longurl'];
        header("location:$url");
        }
        catch (Exception $e) {
            print('Error: ' . $e->getMessage());
        }
        $query="INSERT INTO transaction (name,email,phone,amount,pay_to) VALUES ('$name','$email','$phone','$amount','$pay_to')";
        $run=mysqli_query($con,$query);
    }
?>