<?php
include("header.php");

$con=mysqli_connect("localhost","root","","ehms");
session_start();
if(isset($_POST['patsub'])){
  $email=$_POST['email'];
  $password=$_POST['password2'];
  $query="select * from ptreg where email='$email' and password='$password';";
	$result=mysqli_query($con,$query);
	if(mysqli_num_rows($result)!=0)
	{
    $row=mysqli_fetch_array($result);
    $_SESSION['username'] = $row['fname']." ".$row['lname'];
        $_SESSION['fname'] = $row['fname'];
        $_SESSION['lname'] = $row['lname'];
        $_SESSION['gender'] = $row['gender'];
        $_SESSION['contact'] = $row['contact'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['pid'] = $row['pid'];
    ?>
    <script>
      alert("Login Successfull.")
    </script>a
    <?php
		header("location:connect.php");
	}
  else{
    ?>
    <script>
      alert("Invalid Email and Password.")
    </script>
    <?php
  }
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="style2.css">
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    </head>
        <style type="text/css">
            #inputbtn:hover{cursor:pointer;}
        .card{
            background: #222527c7;
            border-top-left-radius: 5% 5%;
            border-bottom-left-radius: 5% 5%;
            border-top-right-radius: 5% 5%;
            border-bottom-right-radius: 5% 5%;

            background: rgba(30, 94, 119, 0.21);
            box-shadow: 11px 18px 4px rgba(0, 0, 0, 0.25);
            border-radius: 25px;
        }
        </style>
    <body style="background-color: white; background-size: cover;">
        <nav class="navbar navbar-expand-lg navbar-dark " id="mainNav" style="background-color: black;">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="login.php" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;"><h4><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp HEALTHCARE</h4></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>HOME</h6></a>
                        </li>

                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="about.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>ABOUT US</h6></a>
                        </li>

                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="contact.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>CONTACT</h6></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp LOGIN</h6></a>
                        </li>
                        
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="gallery.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp GALLERY</h6></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container-fluid" style="margin-top:60px;margin-bottom:60px;color:#34495E;">
        <div class="row">

        

            <div class="col-md-7" style="padding-left: 180px; ">
                 <div style="-webkit-animation: mover 2s infinite alternate; animation: mover 1s infinite alternate;">
            <img src="3.jpg" alt="" style="width: 30%;padding-left: 30px;margin-top: 160px;margin-bottom:25px">
        </div>
        <div style="color: black;">
            <h4 style="font-family: 'IBM Plex Sans', sans-serif;"> We are here to help!</h4>
          </div>

         </div>

         <div class="col-md-4" style="margin-top: 5%;right: 8%">
          <div class="card" style="font-family: 'IBM Plex Sans', sans-serif;">
            <div class="card-body">
              <center>
                <i class="fa fa-hospital-o fa-3x" aria-hidden="true" style="color:#0062cc"></i>
                <br>
              <h3 style="margin-top: 10%">Patient Login</h3><br>
              <form class="form-group" method="post" action="">
                <div class="row" style="margin-top: 10%">
                  <div class="col-md-4"><label>Email-ID: </label></div>
                  <div class="col-md-8"><input type="text" name="email" class="form-control" placeholder="enter email ID" required/></div><br><br>
                  <div class="col-md-4" style="margin-top: 8%" ><label>Password: </label></div>
                  <div class="col-md-8" style="margin-top: 8%"><input type="password" class="form-control" name="password2" placeholder="enter password" required/></div><br><br><br>
                </div>
                <div class="row">
                 <div class="col-md-4"  style="padding-left: 160px;margin-top: 10%">
                    <center><input type="submit" id="inputbtn" name="patsub" value="Login" class="btn btn-primary"></center></div>           
                 <!--  <div class="col-md-8" style="margin-top: 10%">
                    <a href="index.php" class="btn btn-primary">Back</a></div> -->
                </div>
              </form>
            </center>
            </div>
          </div>
        </div>
        </div>
        </div>
 <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

    </body>
</html>



