<?php
if(isset($_POST['consub']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$contact=$_POST['contact'];
$message=$_POST['message'];


//established connection
$con=mysqli_connect("localhost","root","","ehms");
$query="INSERT INTO `contact`(`name`, `email`, `contact`, `message`) VALUES ('$name','$email','$contact','$message')";
if(mysqli_query($con,$query))
{
    ?>
    <script>
        // alert("Submitted Successfully.");
        if(confirm("Inserted Successfully."))
        {
            window.location.href = "contact.php";
        }
    </script>
    <?php
}
else
{
    ?>
    <script>
        alert("Not Submitted Successfully.");
    </script>
    <?php
}
}
?>