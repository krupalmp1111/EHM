1. Download the zip file
2. Extract the file and copy hospital folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)

Login Details
Login Details for admin : admin/admin
Login Details for Patient: Parth@gmail.com/Partj@123
Login Details for Doctor: manan@gmail.com.com/Manan@123
Login Details for Lab : lab/lab
