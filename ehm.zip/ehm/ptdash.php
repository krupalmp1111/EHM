<?php
session_start();
$con=mysqli_connect("localhost","root","","ehms");
if(isset($_POST['patsub1'])){
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];
$gender=$_POST['gender'];
$contact=$_POST['contact'];
if($password==$cpassword)
{

    $q1=mysqli_query($con,'SELECT * FROM `ptreg` WHERE `email`="'.$email.'"');
    if(mysqli_num_rows($q1)==0)
    {
        $q2=mysqli_query($con,'SELECT * FROM `ptreg` WHERE `contact`="'.$contact.'"');
        if(mysqli_num_rows($q2)==0)
        {
            $query="insert into ptreg(fname,lname,gender,email,contact,password,cpassword) values ('$fname','$lname','$gender','$email','$contact','$password','$cpassword');";
            $result=mysqli_query($con,$query);
            if($result){
                $_SESSION['username'] = $_POST['fname']." ".$_POST['lname'];
                $_SESSION['fname'] = $_POST['fname'];
                $_SESSION['lname'] = $_POST['lname'];
                $_SESSION['gender'] = $_POST['gender'];
                $_SESSION['contact'] = $_POST['contact'];
                $_SESSION['email'] = $_POST['email'];
                header("Location:ptlogin.php");
            }
        }
        else
        {
        echo '<script>if(confirm("This Phone number is already exist in system")){window.location.href="login.php";}else{window.location.href="login.php";}</script>';

        }
       
    }
    else{
        echo '<script>if(confirm("This Email is already exist in system")){window.location.href="login.php";}else{window.location.href="login.php";}</script>';
    }
   
}
}