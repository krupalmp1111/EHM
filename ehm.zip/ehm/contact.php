<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="style2.css">
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    </head>
        <style type="text/css">
            #inputbtn:hover{cursor:pointer;}
        .card{
            background: #222527c7;
            border-top-left-radius: 5% 5%;
            border-bottom-left-radius: 5% 5%;
            border-top-right-radius: 5% 5%;
            border-bottom-right-radius: 5% 5%;

            background: rgba(30, 94, 119, 0.21);
            box-shadow: 11px 18px 4px rgba(0, 0, 0, 0.25);
            border-radius: 25px;
        }
        </style>
        <style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

.btncon {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}
</style>
    <body style="background-color: white; background-size: cover;">
        <nav class="navbar navbar-expand-lg navbar-dark " id="mainNav" style="background-color: black;">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="login.php" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;"><h4><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp HEALTHCARE</h4></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="home.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>HOME</h6></a>
                        </li>

                        <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="about.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>ABOUT US</h6></a>
                        </li>

                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="contact.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>CONTACT</h6></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link js-scroll-trigger" href="login.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp LOGIN</h6></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="gallery.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>&nbsp &nbsp &nbsp &nbsp &nbsp GALLERY</h6></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
  <div style="text-align:center">
    <h2>Contact Us</h2>
  </div>
  <div class="row">
    <div class="column">
    </div>
    <div class="column">
      <form method="post" action="contact-register.php">
        <label for="fname">Mention your First Name</label>
        <input type="text" id="fname" name="name" placeholder="Your First name..">
        <label for="lname">Mention your Email</label>
        <input type="text" id="email" name="email" placeholder="Your Email..">
        <label for="contact">Mention your Contact</label>
        <input type="text" id="contact" name="contact" placeholder="Your Contact..">
        
        <label for="message">Mention your Message</label>
        <textarea id="message" name="message" placeholder="Describe something.." style="height:170px"></textarea>
        <input type="submit" class="btncon" name="consub" onclick="return checklen();" value="Submit"/>
      </form>
    </div>
  </div>
</div>

</body>
</html>

